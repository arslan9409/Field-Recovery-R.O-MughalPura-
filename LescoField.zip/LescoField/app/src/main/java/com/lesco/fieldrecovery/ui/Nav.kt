package com.lesco.fieldrecovery.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.lesco.fieldrecovery.AppViewModel

@Composable fun AppNav(vm: AppViewModel) {
    val nav = rememberNavController()
    NavHost(nav, "splash") {
        composable("splash") { SplashScreen { nav.navigate("dashboard") { popUpTo("splash") { inclusive = true } } } }
        composable("dashboard") { DashboardScreen(vm, nav) }
        composable("form?id={id}", arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })) {
            FormScreen(vm, nav, it.arguments?.getString("id")) }
        composable("history") { HistoryScreen(vm, nav) }
        composable("detail/{id}") { DetailScreen(vm, nav, it.arguments!!.getString("id")!!) }
        composable("camera/{id}") { CameraScreen(vm, nav, it.arguments!!.getString("id")!!) }
        composable("export") { ExportScreen(vm, nav) }
        composable("settings") { SettingsScreen(vm, nav) }
    }
}
