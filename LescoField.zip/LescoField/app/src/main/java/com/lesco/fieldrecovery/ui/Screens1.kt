package com.lesco.fieldrecovery.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.lesco.fieldrecovery.AppViewModel
import com.lesco.fieldrecovery.R
import com.lesco.fieldrecovery.data.*
import com.lesco.fieldrecovery.export.gpsText
import com.lesco.fieldrecovery.util.Fmt
import com.lesco.fieldrecovery.util.Money
import kotlinx.coroutines.delay

@Composable fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) { delay(1600); onDone() }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Image(painterResource(R.drawable.lesco_logo), "Application logo", Modifier.size(200.dp))
        Spacer(Modifier.height(20.dp))
        Text("LESCO Field Recovery & Inspection", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Blue)
        Text("Revenue Office MughalPura, Lahore", color = Green, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(28.dp))
        Text("Made by Arslan Mughal", style = MaterialTheme.typography.labelLarge)
    }
}

@Composable fun DashboardScreen(vm: AppViewModel, nav: NavController) {
    val all by vm.all.collectAsState()
    Screen("LESCO Field Recovery", null, actions = { IconButton(onClick = { nav.navigate("settings") }) { Icon(Icons.Default.Settings, "Settings") } }) { pad ->
        val list = all
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Revenue Office MughalPura, Lahore", color = Green, fontWeight = FontWeight.SemiBold)
            if (list == null) { LinearProgressIndicator(Modifier.fillMaxWidth()) } else {
                val today = Fmt.startOfDay(System.currentTimeMillis())
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Stat("Inspections", list.size.toString(), Modifier.weight(1f))
                    Stat("Today", list.count { it.inspection.inspectedAt >= today }.toString(), Modifier.weight(1f))
                }
                Stat("Total recorded pending", Money.format(totalPaisa(list)), Modifier.fillMaxWidth())
                InfoCard {
                    Text("By defaulter category", fontWeight = FontWeight.Bold)
                    if (list.isEmpty()) Text("No records yet. Start with a new inspection.")
                    DefaulterCategory.entries.forEach { c ->
                        val g = list.filter { it.inspection.category == c }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(c.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Text("${g.size} · ${Money.format(totalPaisa(g))}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            Button({ nav.navigate("form") }, Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("＋  New Inspection", fontSize = 17.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton({ nav.navigate("history") }, Modifier.weight(1f).height(52.dp)) { Text("History") }
                OutlinedButton({ nav.navigate("export") }, Modifier.weight(1f).height(52.dp)) { Text("Export Reports") }
            }
            Text("Data is stored on this device only. Keep exported copies somewhere safe.", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable private fun Stat(label: String, value: String, modifier: Modifier) =
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(14.dp)) { Text(label, style = MaterialTheme.typography.labelMedium); Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
    }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable fun HistoryScreen(vm: AppViewModel, nav: NavController) {
    val list by vm.filtered.collectAsState(); val f by vm.filter.collectAsState(); val sel by vm.selection.collectAsState()
    var showFilters by remember { mutableStateOf(false) }
    Screen("History", { nav.popBackStack() }, actions = {
        if (sel.isNotEmpty()) { TextButton(onClick = { nav.navigate("export") }) { Text("Export ${sel.size}", color = MaterialTheme.colorScheme.onPrimary) }
            TextButton(onClick = { vm.clearSelection() }) { Text("Clear", color = MaterialTheme.colorScheme.onPrimary) } }
        IconButton(onClick = { showFilters = !showFilters }) { Icon(Icons.Default.Search, "Filters") }
    }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(f.query, { vm.filter.value = f.copy(query = it) }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                label = { Text("Search reference, name, address, remarks") })
            if (showFilters) InfoCard {
                Dropdown("Category", f.category, DefaulterCategory.entries, { it.label }, "All categories") { vm.filter.value = f.copy(category = it) }
                Dropdown("Meter status", f.meter, MeterStatus.entries, { it.label }, "All meter statuses") { vm.filter.value = f.copy(meter = it) }
                Dropdown("Payment / legal action", f.legal, LegalAction.entries, { it.label }, "All actions") { vm.filter.value = f.copy(legal = it) }
                Dropdown("Photos", f.hasPhotos, listOf(true, false), { if (it) "With photos" else "Without photos" }, "Any") { vm.filter.value = f.copy(hasPhotos = it) }
                Dropdown("Date range", null as Int?, listOf(0, 7, 30), { when (it) { 0 -> "Today"; 7 -> "Last 7 days"; else -> "Last 30 days" } }, "Choose period…") { d ->
                    vm.filter.value = if (d == null) f.copy(fromMs = null, toMs = null) else f.copy(fromMs = Fmt.startOfDay(System.currentTimeMillis() - d * 86_400_000L), toMs = System.currentTimeMillis()) }
                Dropdown("Sort", f.sort, SortBy.entries, { it.label }) { vm.filter.value = f.copy(sort = it ?: SortBy.NEWEST) }
                TextButton({ vm.filter.value = HistoryFilter() }) { Text("Clear filters") }
            }
            val l = list
            if (l == null) LinearProgressIndicator(Modifier.fillMaxWidth())
            else {
                Text("${l.size} records · ${Money.format(totalPaisa(l))}" + if (f.isActive) "  (filtered)" else "", fontWeight = FontWeight.SemiBold)
                if (l.isEmpty()) Text(if (f.isActive) "No records match these filters." else "No inspections saved yet.", Modifier.padding(16.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(l, key = { it.inspection.id }) { r ->
                        val i = r.inspection; val picked = i.id in sel
                        Card(Modifier.fillMaxWidth().clickable { if (sel.isNotEmpty()) vm.toggleSelect(i.id) else nav.navigate("detail/${i.id}") },
                            colors = CardDefaults.cardColors(containerColor = if (picked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(picked, { vm.toggleSelect(i.id) })
                                Column(Modifier.weight(1f)) {
                                    Text(i.referenceNumber, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                    Text(i.consumerInfo.ifEmpty { "(no name)" }, maxLines = 1, style = MaterialTheme.typography.bodyMedium)
                                    Text("${Fmt.dateTime(i.inspectedAt)} · ${i.category.label}", style = MaterialTheme.typography.labelSmall)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(Money.format(i.pendingPaisa), fontWeight = FontWeight.SemiBold, color = Green)
                                    Text("${r.photos.size} photo(s)", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun DetailScreen(vm: AppViewModel, nav: NavController, id: String) {
    val ctx = LocalContext.current
    val rec by remember(id) { vm.observe(id) }.collectAsState(initial = null)
    var confirmDelete by remember { mutableStateOf(false) }
    var removePhotoId by remember { mutableStateOf<String?>(null) }
    var viewPath by remember { mutableStateOf<String?>(null) }
    val snack = remember { SnackbarHostState() }
    val r = rec
    Screen("Inspection", { nav.popBackStack() }, snack = snack, actions = {
        if (r != null) { IconButton(onClick = { nav.navigate("form?id=$id") }) { Icon(Icons.Default.Edit, "Edit") }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Delete") } }
    }) { pad ->
        if (r == null) { Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return@Screen }
        val i = r.inspection
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard {
                Text(i.referenceNumber, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Blue)
                Text(Money.format(i.pendingPaisa), fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Green)
                Labeled("Date & time", Fmt.dateTime(i.inspectedAt))
                Labeled("Consumer name & address", i.consumerInfo.ifEmpty { "-" })
                Labeled("Defaulter category", i.category.label); Labeled("Meter status", i.meterStatus.label)
                Labeled("Payment / legal action", i.legalAction.label); Labeled("Field remarks", i.remarks.ifEmpty { "-" })
                Labeled("GPS", gpsText(r))
                Text("Location is recorded as reported by the device; it is not independently verified.", style = MaterialTheme.typography.labelSmall)
            }
            Text("Photographs (${r.photos.size})", fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(r.photos, key = { it.id }) { p -> PhotoThumb(p.filePath, 120, Modifier.size(120.dp).clickable { viewPath = p.filePath }) }
            }
            Button({ nav.navigate("camera/$id") }, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Capture photo") }
            r.photos.forEach { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(p.fileName, style = MaterialTheme.typography.labelSmall); Text(Fmt.gps(p.latitude, p.longitude, p.accuracyM), style = MaterialTheme.typography.labelSmall) }
                    TextButton({ val f = java.io.File(p.filePath)
                        if (f.exists()) runCatching { ctx.startActivity(vm.shareIntent(f, "image/jpeg")) } else Unit }) { Text("Share") }
                    TextButton({ removePhotoId = p.id }) { Text("Remove") }
                }
            }
        }
        if (confirmDelete) Confirm("Delete this record?", "Reference ${i.referenceNumber} and its ${r.photos.size} linked photograph(s) will be permanently deleted from this device.", "Delete",
            onOk = { confirmDelete = false; vm.delete(id) { err -> if (err == null) nav.popBackStack() } }, onDismiss = { confirmDelete = false })
        removePhotoId?.let { pid -> Confirm("Remove photo?", "This photograph will be permanently deleted from this device.", "Remove",
            onOk = { vm.removePhoto(pid); removePhotoId = null }, onDismiss = { removePhotoId = null }) }
        viewPath?.let { path -> AlertDialog(onDismissRequest = { viewPath = null }, confirmButton = { TextButton({ viewPath = null }) { Text("Close") } },
            text = { PhotoThumb(path, 0, Modifier.fillMaxWidth().heightIn(min = 300.dp), maxSide = 1600, fit = true) }) }
    }
}
