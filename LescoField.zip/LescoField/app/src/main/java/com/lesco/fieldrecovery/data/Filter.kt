package com.lesco.fieldrecovery.data

enum class SortBy(val label: String) { NEWEST("Newest"), OLDEST("Oldest"), REFERENCE("Reference"), AMOUNT("Amount (high)") }

data class HistoryFilter(
    val query: String = "",
    val fromMs: Long? = null,
    val toMs: Long? = null,          // inclusive end-of-day
    val category: DefaulterCategory? = null,
    val meter: MeterStatus? = null,
    val legal: LegalAction? = null,
    val hasPhotos: Boolean? = null,
    val sort: SortBy = SortBy.NEWEST
) {
    val isActive get() = query.isNotBlank() || fromMs != null || toMs != null || category != null ||
        meter != null || legal != null || hasPhotos != null

    fun summary(): String {
        val p = mutableListOf<String>()
        if (query.isNotBlank()) p += "Search: \"${query.trim()}\""
        if (fromMs != null || toMs != null)
            p += "Dates: ${fromMs?.let { com.lesco.fieldrecovery.util.Fmt.date(it) } ?: "any"} to ${toMs?.let { com.lesco.fieldrecovery.util.Fmt.date(it) } ?: "any"}"
        category?.let { p += "Category: ${it.label}" }
        meter?.let { p += "Meter: ${it.label}" }
        legal?.let { p += "Action: ${it.label}" }
        hasPhotos?.let { p += if (it) "With photos" else "Without photos" }
        return if (p.isEmpty()) "No filters (all records)" else p.joinToString("; ")
    }
}

fun applyFilter(all: List<InspectionWithPhotos>, f: HistoryFilter): List<InspectionWithPhotos> {
    val q = f.query.trim().lowercase()
    val out = all.filter { r ->
        val i = r.inspection
        (q.isEmpty() || i.referenceNumber.lowercase().contains(q) || i.consumerInfo.lowercase().contains(q) || i.remarks.lowercase().contains(q)) &&
            (f.fromMs == null || i.inspectedAt >= f.fromMs) && (f.toMs == null || i.inspectedAt <= f.toMs) &&
            (f.category == null || i.category == f.category) && (f.meter == null || i.meterStatus == f.meter) &&
            (f.legal == null || i.legalAction == f.legal) &&
            (f.hasPhotos == null || (r.photos.isNotEmpty() == f.hasPhotos))
    }
    return when (f.sort) {
        SortBy.NEWEST -> out.sortedByDescending { it.inspection.inspectedAt }
        SortBy.OLDEST -> out.sortedBy { it.inspection.inspectedAt }
        SortBy.REFERENCE -> out.sortedBy { it.inspection.referenceNumber.lowercase() }
        SortBy.AMOUNT -> out.sortedByDescending { it.inspection.pendingPaisa }
    }
}

/** Totals come from inspection rows only, never from photo rows. */
fun totalPaisa(list: List<InspectionWithPhotos>): Long = list.sumOf { it.inspection.pendingPaisa }
