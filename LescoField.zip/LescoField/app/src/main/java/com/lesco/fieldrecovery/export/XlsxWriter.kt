package com.lesco.fieldrecovery.export

import com.lesco.fieldrecovery.data.InspectionWithPhotos
import com.lesco.fieldrecovery.util.Fmt
import com.lesco.fieldrecovery.util.Money
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Minimal, dependency-free OOXML writer. All text is written as inline strings, so nothing is ever a formula. */
object XlsxWriter {
    val HEADERS = listOf("S.No", "Date & Time", "Reference Number", "Consumer Name/Address", "Pending Amount (Rs.)",
        "Defaulter Category", "Meter Status", "Legal / Payment Status", "Field Remarks", "GPS Location", "Photo File Name")
    private val WIDTHS = listOf(7, 18, 20, 38, 18, 30, 36, 38, 50, 30, 40)

    fun esc(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c.code < 0x20 && c != '\n' && c != '\t' && c != '\r') continue   // illegal in XML 1.0
            when (c) { '&' -> sb.append("&amp;"); '<' -> sb.append("&lt;"); '>' -> sb.append("&gt;"); '"' -> sb.append("&quot;"); else -> sb.append(c) }
        }
        return sb.toString()
    }
    private fun col(n: Int) = ('A' + n).toString()
    private fun str(ref: String, text: String, style: Int) =
        "<c r=\"$ref\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(text)}</t></is></c>"

    /** Rows should already be in the order they should be numbered. */
    fun write(file: File, rows: List<InspectionWithPhotos>, meta: ReportMeta) {
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".part")
        ZipOutputStream(FileOutputStream(tmp)).use { z ->
            fun entry(name: String, body: String) { z.putNextEntry(ZipEntry(name)); z.write(body.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>""")
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Inspections" sheetId="1" r:id="rId1"/><sheet name="Summary" sheetId="2" r:id="rId2"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>""")
            // styles: 0 default, 1 header, 2 currency, 3 wrapped text, 4 bold title
            entry("xl/styles.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="&quot;Rs. &quot;#,##0.00"/></numFmts><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="14"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0B3C8C"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFBBBBBB"/></left><right style="thin"><color rgb="FFBBBBBB"/></right><top style="thin"><color rgb="FFBBBBBB"/></top><bottom style="thin"><color rgb="FFBBBBBB"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment vertical="top"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"><alignment vertical="top"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs></styleSheet>""")

            val s1 = StringBuilder("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>""")
            WIDTHS.forEachIndexed { i, w -> s1.append("""<col min="${i + 1}" max="${i + 1}" width="$w" customWidth="1"/>""") }
            s1.append("</cols><sheetData><row r=\"1\" ht=\"30\" customHeight=\"1\">")
            HEADERS.forEachIndexed { i, h -> s1.append(str("${col(i)}1", h, 1)) }
            s1.append("</row>")
            rows.forEachIndexed { idx, r ->
                val n = idx + 2; val i = r.inspection
                s1.append("<row r=\"$n\">")
                s1.append("""<c r="A$n" s="0"><v>${idx + 1}</v></c>""")
                s1.append(str("B$n", Fmt.dateTime(i.inspectedAt), 0))
                s1.append(str("C$n", i.referenceNumber, 0))
                s1.append(str("D$n", i.consumerInfo, 3))
                s1.append("""<c r="E$n" s="2"><v>${Money.plain(i.pendingPaisa)}</v></c>""")
                s1.append(str("F$n", i.category.label, 3)); s1.append(str("G$n", i.meterStatus.label, 3))
                s1.append(str("H$n", i.legalAction.label, 3)); s1.append(str("I$n", i.remarks, 3))
                s1.append(str("J$n", gpsText(r), 3)); s1.append(str("K$n", photoNames(r), 3))
                s1.append("</row>")
            }
            s1.append("</sheetData></worksheet>")
            entry("xl/worksheets/sheet1.xml", s1.toString())

            val total = Money.plain(rows.sumOf { it.inspection.pendingPaisa })
            val sum = listOf("Report" to meta.title, "Office" to meta.office, "Generated" to Fmt.dateTimeSec(meta.generatedAt),
                "Filters" to meta.filterSummary, "Records" to rows.size.toString())
            val s2 = StringBuilder("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols><col min="1" max="1" width="18" customWidth="1"/><col min="2" max="2" width="70" customWidth="1"/></cols><sheetData>""")
            sum.forEachIndexed { k, (a, b) -> s2.append("<row r=\"${k + 1}\">${str("A${k + 1}", a, if (k == 0) 4 else 0)}${str("B${k + 1}", b, 3)}</row>") }
            val tr = sum.size + 1
            s2.append("<row r=\"$tr\">${str("A$tr", "Total Pending", 0)}<c r=\"B$tr\" s=\"2\"><v>$total</v></c></row></sheetData></worksheet>")
            entry("xl/worksheets/sheet2.xml", s2.toString())
        }
        if (!tmp.renameTo(file)) { tmp.delete(); error("Could not finalize Excel file") }
    }
}
