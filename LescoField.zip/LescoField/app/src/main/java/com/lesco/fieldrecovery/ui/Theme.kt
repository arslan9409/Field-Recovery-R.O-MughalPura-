package com.lesco.fieldrecovery.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF0B3C8C); val Green = Color(0xFF1B8A3C)
private val Light = lightColorScheme(primary = Blue, onPrimary = Color.White, secondary = Green, onSecondary = Color.White,
    tertiary = Green, background = Color(0xFFF5F7FB), surface = Color.White, primaryContainer = Color(0xFFD9E5FA), onPrimaryContainer = Color(0xFF05234F))
private val Dark = darkColorScheme(primary = Color(0xFF9DBCF2), onPrimary = Color(0xFF05234F), secondary = Color(0xFF6FD08A), onSecondary = Color(0xFF00391A),
    background = Color(0xFF10141C), surface = Color(0xFF181D27), primaryContainer = Color(0xFF1F3A6E), onPrimaryContainer = Color(0xFFD9E5FA))

@Composable fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
