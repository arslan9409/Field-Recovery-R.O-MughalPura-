package com.lesco.fieldrecovery.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

fun decodeScaled(path: String, maxSide: Int): Bitmap? {
    if (!File(path).exists()) return null
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o); if (o.outWidth <= 0) return null
    var s = 1; while (maxOf(o.outWidth, o.outHeight) / s > maxSide) s *= 2
    val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
    val deg = when (androidx.exifinterface.media.ExifInterface(path).getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
    if (deg == 0f) return bmp
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, android.graphics.Matrix().apply { postRotate(deg) }, true)
}

/** Loads a downsampled bitmap off the main thread; shows a placeholder if the file is missing. */
@Composable fun PhotoThumb(path: String, size: Int, modifier: Modifier = Modifier, maxSide: Int = 256, fit: Boolean = false) {
    val bmp by produceState<Bitmap?>(null, path) { value = withContext(Dispatchers.IO) { decodeScaled(path, maxSide) } }
    val missing = remember(path) { !File(path).exists() }
    Box(modifier.clip(RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), "Inspection photo", Modifier.fillMaxSize(), contentScale = if (fit) ContentScale.Fit else ContentScale.Crop)
        else Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surfaceVariant) {
            Box(contentAlignment = Alignment.Center) { Text(if (missing) "File missing" else "…", style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Screen(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {},
                       snack: SnackbarHostState? = null, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text(title) },
            navigationIcon = { if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = actions,
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = MaterialTheme.colorScheme.onPrimary, navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                actionIconContentColor = MaterialTheme.colorScheme.onPrimary)) },
        snackbarHost = { snack?.let { SnackbarHost(it) } },
        containerColor = MaterialTheme.colorScheme.background, content = content)
}

@Composable fun InfoCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp), content = content) }

@Composable fun Labeled(label: String, value: String) {
    Column { Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary); Text(value, style = MaterialTheme.typography.bodyLarge) }
}

@Composable fun Confirm(title: String, text: String, ok: String, onOk: () -> Unit, onDismiss: () -> Unit) =
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = onOk) { Text(ok) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun <T> Dropdown(label: String, value: T?, options: List<T>, text: (T) -> String, anyLabel: String? = null, onSelect: (T?) -> Unit) {
    var exp by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = exp, onExpandedChange = { exp = it }) {
        OutlinedTextField(value = value?.let(text) ?: (anyLabel ?: ""), onValueChange = {}, readOnly = true, label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(exp) }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded = exp, onDismissRequest = { exp = false }) {
            if (anyLabel != null) DropdownMenuItem(text = { Text(anyLabel) }, onClick = { onSelect(null); exp = false })
            options.forEach { DropdownMenuItem(text = { Text(text(it)) }, onClick = { onSelect(it); exp = false }) }
        }
    }
}
