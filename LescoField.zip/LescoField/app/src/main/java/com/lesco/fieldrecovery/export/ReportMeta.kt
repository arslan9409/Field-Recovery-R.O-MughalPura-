package com.lesco.fieldrecovery.export

import com.lesco.fieldrecovery.data.InspectionWithPhotos
import com.lesco.fieldrecovery.util.Fmt

data class ReportMeta(val title: String, val office: String, val generatedAt: Long, val filterSummary: String)

/** GPS shown for a record: inspection-level fix if present, otherwise the first geotagged photo. */
fun gpsText(r: InspectionWithPhotos): String {
    val i = r.inspection
    if (i.latitude != null && i.longitude != null) return Fmt.gps(i.latitude, i.longitude, i.accuracyM)
    val p = r.photos.firstOrNull { it.latitude != null && it.longitude != null }
    return if (p != null) Fmt.gps(p.latitude, p.longitude, p.accuracyM) else "Not recorded"
}
fun photoNames(r: InspectionWithPhotos): String = r.photos.joinToString(", ") { it.fileName }.ifEmpty { "No photo" }
