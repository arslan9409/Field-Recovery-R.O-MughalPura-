package com.lesco.fieldrecovery.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavController
import com.lesco.fieldrecovery.AppViewModel
import com.lesco.fieldrecovery.ExportedFile
import com.lesco.fieldrecovery.data.*
import com.lesco.fieldrecovery.util.*
import kotlinx.coroutines.launch
import java.io.File

private fun android.content.Context.has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
private fun android.content.Context.hasLocation() = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)

@Composable fun FormScreen(vm: AppViewModel, nav: NavController, editId: String?) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope(); val snack = remember { SnackbarHostState() }
    var existing by remember { mutableStateOf<Inspection?>(null) }
    var ref by rememberSaveable { mutableStateOf("") }; var consumer by rememberSaveable { mutableStateOf("") }
    var amount by rememberSaveable { mutableStateOf("") }; var remarks by rememberSaveable { mutableStateOf("") }
    var cat by rememberSaveable { mutableStateOf(DefaulterCategory.M1_2) }
    var meter by rememberSaveable { mutableStateOf(MeterStatus.RUNNING) }
    var legal by rememberSaveable { mutableStateOf(LegalAction.PROMISED) }
    var touched by rememberSaveable { mutableStateOf(false) }
    var refErr by remember { mutableStateOf<String?>(null) }; var amtErr by remember { mutableStateOf<String?>(null) }
    var dup by remember { mutableStateOf<Pair<Inspection, Boolean>?>(null) }
    var showDiscard by remember { mutableStateOf(false) }; var saving by remember { mutableStateOf(false) }
    val tracker = remember { LocationTracker(ctx) }
    DisposableEffect(Unit) { onDispose { tracker.stop() } }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tracker.start(ctx.hasLocation()) }

    fun fill(i: Inspection) { ref = i.referenceNumber; consumer = i.consumerInfo; amount = if (i.pendingPaisa == 0L) "" else Money.plain(i.pendingPaisa)
        remarks = i.remarks; cat = i.category; meter = i.meterStatus; legal = i.legalAction }
    LaunchedEffect(editId) { if (editId != null && existing == null) vm.get(editId)?.let { existing = it.inspection; if (!touched) fill(it.inspection) } }

    fun commit(thenCamera: Boolean) {
        val paisa = Money.parse(amount) ?: return
        val old = existing; val fix = tracker.best
        val rec = Inspection(id = old?.id ?: java.util.UUID.randomUUID().toString(), referenceNumber = ref.trim(), consumerInfo = consumer, pendingPaisa = paisa,
            category = cat, meterStatus = meter, legalAction = legal, remarks = remarks,
            inspectedAt = old?.inspectedAt ?: System.currentTimeMillis(),
            latitude = fix?.latitude ?: old?.latitude, longitude = fix?.longitude ?: old?.longitude,
            accuracyM = if (fix != null) fix.accuracy else old?.accuracyM, locationAt = if (fix != null) fix.time else old?.locationAt,
            updatedAt = System.currentTimeMillis())
        saving = true
        vm.save(rec, old == null) { err ->
            saving = false
            if (err != null) scope.launch { snack.showSnackbar("Not saved: $err") }
            else { touched = false
                if (thenCamera) { nav.navigate("detail/${rec.id}") { popUpTo("dashboard") }; nav.navigate("camera/${rec.id}") }
                else nav.popBackStack() }
        }
    }
    fun trySave(thenCamera: Boolean) {
        refErr = if (ref.trim().isEmpty()) "Reference number is required" else null
        amtErr = if (Money.parse(amount) == null) "Enter a valid amount (digits, optional 2 decimals)" else null
        if (refErr != null || amtErr != null) return
        scope.launch { val d = vm.duplicates(ref, existing?.id); if (d.isNotEmpty()) dup = d.first() to thenCamera else commit(thenCamera) }
    }
    fun leave() { if (touched) showDiscard = true else nav.popBackStack() }
    BackHandler(touched) { showDiscard = true }

    Screen(if (editId == null) "New Inspection" else "Edit Inspection", { leave() }, snack = snack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp).imePadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(ref, { ref = it; touched = true; refErr = null }, Modifier.fillMaxWidth(), label = { Text("Reference Number *") }, singleLine = true,
                textStyle = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp), isError = refErr != null, supportingText = { refErr?.let { Text(it) } })
            OutlinedTextField(consumer, { consumer = it; touched = true }, Modifier.fillMaxWidth(), label = { Text("Consumer Name & Address") }, minLines = 2)
            OutlinedTextField(amount, { amount = it; touched = true; amtErr = null }, Modifier.fillMaxWidth(), label = { Text("Pending Amount (Rs.)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), isError = amtErr != null, supportingText = { amtErr?.let { Text(it) } })
            Dropdown("Defaulter Category", cat, DefaulterCategory.entries, { it.label }) { cat = it ?: cat; touched = true }
            Dropdown("Meter Status", meter, MeterStatus.entries, { it.label }) { meter = it ?: meter; touched = true }
            Dropdown("Payment / Legal Action", legal, LegalAction.entries, { it.label }) { legal = it ?: legal; touched = true }
            OutlinedTextField(remarks, { remarks = it; touched = true }, Modifier.fillMaxWidth(), label = { Text("Custom Remarks / Field Notes") }, minLines = 3)
            InfoCard {
                Text("Location", fontWeight = FontWeight.Bold)
                Text(if (tracker.state == GpsState.IDLE) existing?.let { Fmt.gps(it.latitude, it.longitude, it.accuracyM) } ?: "Not recorded" else tracker.label())
                OutlinedButton({ if (ctx.hasLocation()) tracker.retry(true) else locPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) { Text("Tag current location") }
                Text("Date and time are recorded automatically when the inspection is first saved.", style = MaterialTheme.typography.labelSmall)
            }
            if (saving) LinearProgressIndicator(Modifier.fillMaxWidth())
            Button({ trySave(false) }, Modifier.fillMaxWidth().height(54.dp), enabled = !saving) { Text("Save") }
            Button({ trySave(true) }, Modifier.fillMaxWidth().height(54.dp), enabled = !saving, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Save and Capture Photo") }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton({ existing?.let { fill(it) } ?: run { ref = ""; consumer = ""; amount = ""; remarks = ""; cat = DefaulterCategory.M1_2; meter = MeterStatus.RUNNING; legal = LegalAction.PROMISED }
                    touched = false; refErr = null; amtErr = null }, Modifier.weight(1f).height(48.dp)) { Text("Reset") }
                OutlinedButton({ leave() }, Modifier.weight(1f).height(48.dp)) { Text("Cancel") }
            }
        }
        dup?.let { (d, cam) -> AlertDialog(onDismissRequest = { dup = null }, title = { Text("Reference already exists") },
            text = { Text("Reference ${d.referenceNumber} was already saved on ${Fmt.dateTime(d.inspectedAt)} (${Money.format(d.pendingPaisa)}). Saving will create a separate record; nothing will be overwritten.") },
            confirmButton = { TextButton({ dup = null; commit(cam) }) { Text("Save anyway") } },
            dismissButton = { Row { TextButton({ dup = null; nav.navigate("detail/${d.id}") }) { Text("View existing") }; TextButton({ dup = null }) { Text("Cancel") } } }) }
        if (showDiscard) Confirm("Discard changes?", "Unsaved entries will be lost.", "Discard", { showDiscard = false; touched = false; nav.popBackStack() }, { showDiscard = false })
    }
}

@Composable fun CameraScreen(vm: AppViewModel, nav: NavController, inspectionId: String) {
    val ctx = LocalContext.current; val owner = LocalLifecycleOwner.current
    var rec by remember { mutableStateOf<Inspection?>(null) }
    var granted by remember { mutableStateOf(ctx.has(Manifest.permission.CAMERA)) }
    var shot by remember { mutableStateOf<File?>(null) }; var shotAt by remember { mutableLongStateOf(0L) }
    var snap by remember { mutableStateOf<Triple<Double, Double, Float>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }; var saving by remember { mutableStateOf(false) }
    val tracker = remember { LocationTracker(ctx) }
    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    LaunchedEffect(inspectionId) { rec = vm.get(inspectionId)?.inspection }
    DisposableEffect(Unit) { onDispose { tracker.stop(); shot?.delete() } }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tracker.start(ctx.hasLocation()) }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) {
        if (!granted) camPerm.launch(Manifest.permission.CAMERA)
        if (ctx.hasLocation()) tracker.start(true) else locPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    Screen("Capture Photo", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Text("REF: ${rec?.referenceNumber ?: "…"}", Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(tracker.label(), Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall)
            error?.let { Text(it, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.error) }
            Box(Modifier.weight(1f).fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                val s = shot
                when {
                    !granted -> Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("Camera permission is needed to capture evidence photos.")
                        Button({ camPerm.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") } }
                    s != null -> PhotoThumb(s.path, 0, Modifier.fillMaxSize(), maxSide = 1400, fit = true)
                    else -> AndroidView(factory = { c -> PreviewView(c).also { pv ->
                        val fut = ProcessCameraProvider.getInstance(c)
                        fut.addListener({ try { val prov = fut.get()
                            val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                            prov.unbindAll(); prov.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, prev, imageCapture)
                        } catch (e: Exception) { error = "Camera error: ${e.message}" } }, ContextCompat.getMainExecutor(c)) } }, modifier = Modifier.fillMaxSize())
                }
            }
            if (saving) LinearProgressIndicator(Modifier.fillMaxWidth())
            Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (shot == null) {
                    if (tracker.state == GpsState.TIMEOUT || tracker.state == GpsState.DISABLED)
                        OutlinedButton({ tracker.retry(ctx.hasLocation()) }, Modifier.weight(1f).height(52.dp)) { Text("Retry GPS") }
                    Button({
                        val tmp = File(ctx.cacheDir, "cap_${System.currentTimeMillis()}.jpg")
                        imageCapture.takePicture(ImageCapture.OutputFileOptions.Builder(tmp).build(), ContextCompat.getMainExecutor(ctx),
                            object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                                    shotAt = System.currentTimeMillis(); shot = tmp; error = null
                                    snap = tracker.best?.let { Triple(it.latitude, it.longitude, it.accuracy) }
                                }
                                override fun onError(e: ImageCaptureException) { tmp.delete(); error = "Capture failed: ${e.message}" }
                            })
                    }, Modifier.weight(1f).height(52.dp), enabled = granted && rec != null, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                        Text(if (tracker.best == null) "Capture (no GPS yet)" else "Capture") }
                } else {
                    OutlinedButton({ shot?.delete(); shot = null }, Modifier.weight(1f).height(52.dp), enabled = !saving) { Text("Retake") }
                    Button({
                        val r = rec ?: return@Button; val f = shot ?: return@Button; saving = true
                        vm.addPhoto(inspectionId, r.referenceNumber, f, shotAt, snap?.first, snap?.second, snap?.third) { err ->
                            saving = false
                            if (err == null) { shot = null; nav.popBackStack() } else error = "Photo not saved: $err"
                        }
                    }, Modifier.weight(1f).height(52.dp), enabled = !saving) { Text(if (snap == null) "Save (untagged)" else "Save with GPS") }
                }
            }
        }
    }
}

@Composable fun ExportScreen(vm: AppViewModel, nav: NavController) {
    val ctx = LocalContext.current; val sel by vm.selection.collectAsState(); val f by vm.filter.collectAsState()
    val all by vm.all.collectAsState(); val filtered by vm.filtered.collectAsState()
    var scope by remember { mutableStateOf(if (sel.isNotEmpty()) "selected" else "all") }
    var format by remember { mutableStateOf("xlsx") }
    var busy by remember { mutableStateOf(false) }; var result by remember { mutableStateOf<ExportedFile?>(null) }; var error by remember { mutableStateOf<String?>(null) }
    val count = when (scope) { "selected" -> sel.size; "filtered" -> filtered?.size ?: 0; else -> all?.size ?: 0 }
    @Composable fun opt(sel: Boolean, label: String, on: () -> Unit) = Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { RadioButton(sel, on); Text(label) }
    Screen("Export Reports", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val r = result
            if (r != null) {
                InfoCard {
                    Text("Report created", fontWeight = FontWeight.Bold, color = Green, fontSize = 18.sp)
                    Labeled("File name", r.file.name); Labeled("Format", if (r.mime == "application/pdf") "PDF" else "Excel (.xlsx)")
                    Labeled("Saved in", "App storage: " + r.file.parent); Labeled("Details", r.note)
                }
                Button({ try { ctx.startActivity(vm.shareIntent(r.file, r.mime)) } catch (e: Exception) { error = "Could not open share sheet: ${e.message}" } }, Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Share (WhatsApp and others)") }
                OutlinedButton({ try { ctx.startActivity(vm.openIntent(r.file, r.mime)) } catch (e: Exception) { error = "No installed app can open this file type." } }, Modifier.fillMaxWidth().height(52.dp)) { Text("Open") }
                OutlinedButton({ result = null }, Modifier.fillMaxWidth().height(52.dp)) { Text("Export Another Report") }
            } else {
                InfoCard {
                    Text("Records to include", fontWeight = FontWeight.Bold)
                    opt(scope == "all", "All records (${all?.size ?: 0})") { scope = "all" }
                    opt(scope == "filtered", "Current history filter (${filtered?.size ?: 0}) – ${f.summary()}") { scope = "filtered" }
                    opt(scope == "selected", "Selected in history (${sel.size})") { scope = "selected" }
                }
                InfoCard {
                    Text("Format", fontWeight = FontWeight.Bold)
                    opt(format == "xlsx", "Excel workbook (.xlsx)") { format = "xlsx" }
                    opt(format == "pdf", "PDF – compact table") { format = "pdf" }
                    opt(format == "pdf_detail", "PDF – detailed with photographs") { format = "pdf_detail" }
                }
                Button({ busy = true; error = null
                    vm.export(scope, format) { file, err -> busy = false; result = file; error = err } },
                    Modifier.fillMaxWidth().height(56.dp), enabled = !busy && count > 0) { Text(if (busy) "Generating…" else "Generate report ($count records)") }
                if (count == 0) Text("No records in this scope.")
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable fun SettingsScreen(vm: AppViewModel, nav: NavController) {
    val p = vm.prefs; val theme by vm.theme.collectAsState()
    var office by remember { mutableStateOf(p.officeName) }; var title by remember { mutableStateOf(p.reportTitle) }
    var wm by remember { mutableStateOf(p.watermarkExtra) }; var q by remember { mutableFloatStateOf(p.jpegQuality.toFloat()) }
    Screen("Settings", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(office, { office = it; p.officeName = it }, Modifier.fillMaxWidth(), label = { Text("Office name (reports)") })
            OutlinedTextField(title, { title = it; p.reportTitle = it }, Modifier.fillMaxWidth(), label = { Text("Report title") })
            OutlinedTextField(wm, { wm = it; p.watermarkExtra = it }, Modifier.fillMaxWidth(), label = { Text("Extra watermark line (optional)") },
                supportingText = { Text("Reference number, date/time and GPS are always included.") })
            Text("Photo JPEG quality: ${q.toInt()}")
            Slider(q, { q = it; p.jpegQuality = it.toInt() }, valueRange = 50f..100f)
            Text("Theme", fontWeight = FontWeight.Bold)
            listOf(0 to "System", 1 to "Light", 2 to "Dark").forEach { (v, l) -> Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(theme == v, { vm.setTheme(v) }); Text(l) } }
            InfoCard {
                Text("About", fontWeight = FontWeight.Bold)
                Text("LESCO Field Recovery & Inspection 1.0.0\nRevenue Office MughalPura, Lahore\nMade by Arslan Mughal")
                Text("Privacy: all records and photographs stay on this device. The app uses no internet connection, server, analytics or ads. Camera and location permissions are requested only when you capture a photo or tag a location.")
                Text("Data safety: records are stored on this device only and are not backed up. Export reports regularly and keep copies somewhere safe. Photo watermarks are visual annotations, not tamper-proof evidence. This app is not an official LESCO product unless authorised by LESCO.")
            }
        }
    }
}
