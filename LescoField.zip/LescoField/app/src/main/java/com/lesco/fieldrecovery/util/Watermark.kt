package com.lesco.fieldrecovery.util

import android.graphics.*
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.max

data class WatermarkInfo(
    val reference: String, val capturedAt: Long,
    val lat: Double?, val lon: Double?, val accuracyM: Float?,
    val appName: String = "LESCO Field Recovery & Inspection", val extra: String = ""
)

object Watermark {
    private const val MAX_SIDE = 3000

    /** Builds the text lines burned into the image. Separate so it can be unit tested. */
    fun lines(i: WatermarkInfo): List<String> {
        val gps = if (i.lat != null && i.lon != null)
            "GPS: " + String.format(Locale.US, "%.6f, %.6f", i.lat, i.lon) + (i.accuracyM?.let { String.format(Locale.US, "  (accuracy %.0f m)", it) } ?: "")
        else "GPS: not available (untagged)"
        return listOfNotNull("REF: ${i.reference}", Fmt.dateTimeSec(i.capturedAt), gps, i.extra.takeIf { it.isNotBlank() }, i.appName)
    }

    /** Reads [src], applies EXIF rotation, burns the watermark into the pixels, writes JPEG to [dest]. */
    fun apply(src: File, dest: File, info: WatermarkInfo, quality: Int) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(src.path, bounds)
        require(bounds.outWidth > 0) { "Captured image could not be read" }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
        val raw = BitmapFactory.decodeFile(src.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: error("Captured image could not be decoded")
        val orient = ExifInterface(src.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        }
        val upright = if (m.isIdentity) raw else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        if (upright !== raw) raw.recycle()
        val bmp = upright.copy(Bitmap.Config.ARGB_8888, true)
        if (bmp !== upright) upright.recycle()

        val canvas = Canvas(bmp)
        val ls = lines(info)
        val base = (minOf(bmp.width, bmp.height) * 0.032f).coerceAtLeast(14f)
        val pad = base * 0.6f
        val paints = ls.indices.map { idx ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                typeface = if (idx == 0) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                textSize = if (idx == 0) base * 1.25f else base
                setShadowLayer(base * 0.08f, 0f, 0f, Color.BLACK)
            }
        }
        paints.forEachIndexed { idx, p ->  // shrink a line that would overflow the width
            val avail = bmp.width - 2 * pad
            val w = p.measureText(ls[idx])
            if (w > avail) p.textSize = p.textSize * avail / w
        }
        val lineH = paints.map { it.fontMetrics.let { f -> f.descent - f.ascent } * 1.15f }
        val stripH = lineH.sum() + 2 * pad
        val top = bmp.height - stripH
        canvas.drawRect(0f, top, bmp.width.toFloat(), bmp.height.toFloat(), Paint().apply { color = Color.argb(165, 0, 0, 0) })
        var y = top + pad
        ls.forEachIndexed { idx, t ->
            y += -paints[idx].fontMetrics.ascent
            canvas.drawText(t, pad, y, paints[idx])
            y += paints[idx].fontMetrics.descent + (lineH[idx] - (paints[idx].fontMetrics.descent - paints[idx].fontMetrics.ascent))
        }
        dest.parentFile?.mkdirs()
        FileOutputStream(dest).use { out ->
            if (!bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)) error("Could not write image (storage may be full)")
        }
        bmp.recycle()
    }
}
