package com.lesco.fieldrecovery.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class GpsState { IDLE, ACQUIRING, FIXED, TIMEOUT, DISABLED, NO_PERMISSION }

/** Collects real location fixes only. Never fabricates coordinates. */
class LocationTracker(ctx: Context) {
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val handler = Handler(Looper.getMainLooper())
    var state by mutableStateOf(GpsState.IDLE); private set
    var best by mutableStateOf<Location?>(null); private set

    private val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val b = best
            if (b == null || loc.accuracy <= b.accuracy || loc.time - b.time > 15_000) best = loc
            state = GpsState.FIXED
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    }
    private val timeout = Runnable { if (best == null) { state = GpsState.TIMEOUT; stopUpdates() } }

    @SuppressLint("MissingPermission")
    fun start(hasPermission: Boolean, timeoutMs: Long = 25_000) {
        stop()
        if (!hasPermission) { state = GpsState.NO_PERMISSION; return }
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter {
            try { lm.isProviderEnabled(it) } catch (e: Exception) { false }
        }
        if (providers.isEmpty()) { state = GpsState.DISABLED; return }
        state = GpsState.ACQUIRING
        try { providers.forEach { lm.requestLocationUpdates(it, 1000L, 0f, listener, Looper.getMainLooper()) } }
        catch (e: SecurityException) { state = GpsState.NO_PERMISSION; return }
        handler.postDelayed(timeout, timeoutMs)
    }
    private fun stopUpdates() { try { lm.removeUpdates(listener) } catch (_: Exception) {} }
    fun stop() { handler.removeCallbacks(timeout); stopUpdates() }
    fun retry(hasPermission: Boolean) { best = null; start(hasPermission) }

    fun label(): String = when (state) {
        GpsState.IDLE -> "Location not requested"
        GpsState.ACQUIRING -> "Acquiring GPS…"
        GpsState.FIXED -> best?.let { String.format("GPS fix ±%.0f m", it.accuracy) } ?: "GPS fix"
        GpsState.TIMEOUT -> "No GPS fix (timed out). Retry or save untagged."
        GpsState.DISABLED -> "Location services are off. Turn on GPS or save untagged."
        GpsState.NO_PERMISSION -> "Location permission denied. Photo will be untagged."
    }
}
