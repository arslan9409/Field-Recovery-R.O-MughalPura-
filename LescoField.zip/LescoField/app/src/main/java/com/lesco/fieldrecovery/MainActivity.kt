package com.lesco.fieldrecovery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.lesco.fieldrecovery.ui.AppNav
import com.lesco.fieldrecovery.ui.AppTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { val t by vm.theme.collectAsState(); AppTheme(t) { AppNav(vm) } }
    }
}
