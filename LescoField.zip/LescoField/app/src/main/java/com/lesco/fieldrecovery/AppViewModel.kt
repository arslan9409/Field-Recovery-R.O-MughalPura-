package com.lesco.fieldrecovery

import android.app.Application
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lesco.fieldrecovery.data.*
import com.lesco.fieldrecovery.export.*
import com.lesco.fieldrecovery.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class ExportedFile(val file: File, val mime: String, val note: String)

class AppViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    val prefs = Prefs(app)

    /** null = still loading */
    val all: StateFlow<List<InspectionWithPhotos>?> =
        dao.observeAll().map<List<InspectionWithPhotos>, List<InspectionWithPhotos>?> { it }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val filter = MutableStateFlow(HistoryFilter())
    val filtered: StateFlow<List<InspectionWithPhotos>?> =
        combine(all, filter) { a, f -> a?.let { applyFilter(it, f) } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val selection = MutableStateFlow<Set<String>>(emptySet())
    val theme = MutableStateFlow(prefs.theme)

    fun setTheme(v: Int) { prefs.theme = v; theme.value = v }
    fun toggleSelect(id: String) { selection.value = selection.value.let { if (id in it) it - id else it + id } }
    fun clearSelection() { selection.value = emptySet() }
    fun observe(id: String) = dao.observe(id)

    suspend fun get(id: String) = dao.get(id)
    suspend fun duplicates(ref: String, excludeId: String?) = dao.byReference(ref.trim()).filter { it.id != excludeId }

    fun save(i: Inspection, isNew: Boolean, onResult: (String?) -> Unit) = viewModelScope.launch {
        val err = withContext(Dispatchers.IO) {
            try { if (isNew) dao.insert(i) else dao.update(i); null } catch (e: Exception) { e.message ?: "Could not save record" }
        }
        onResult(err)
    }

    fun delete(id: String, onResult: (String?) -> Unit) = viewModelScope.launch {
        val err = withContext(Dispatchers.IO) {
            try {
                val paths = dao.photoPaths(id)
                dao.delete(id)                       // photos rows cascade
                paths.forEach { runCatching { File(it).delete() } }   // remove files only after the DB commit succeeded
                null
            } catch (e: Exception) { e.message ?: "Could not delete record" }
        }
        onResult(err)
    }

    /** Watermarks the captured file and links it to the inspection. Returns an error message or null. */
    fun addPhoto(inspectionId: String, ref: String, temp: File, capturedAt: Long,
                 lat: Double?, lon: Double?, acc: Float?, onResult: (String?) -> Unit) = viewModelScope.launch {
        val err = withContext(Dispatchers.IO) {
            val name = "${safeName(ref)}_${Fmt.stamp(capturedAt)}_${UUID.randomUUID().toString().take(6)}.jpg"
            val dest = File(app.filesDir, "photos/$name")
            try {
                Watermark.apply(temp, dest, WatermarkInfo(ref, capturedAt, lat, lon, acc, extra = prefs.watermarkExtra), prefs.jpegQuality)
                dao.insertPhoto(Photo(inspectionId = inspectionId, filePath = dest.path, fileName = name, referenceNumber = ref,
                    capturedAt = capturedAt, latitude = lat, longitude = lon, accuracyM = acc))
                null
            } catch (e: Throwable) {
                dest.delete()
                if (e is java.io.IOException) "Storage problem: ${e.message}" else (e.message ?: "Image processing failed")
            } finally { temp.delete() }
        }
        onResult(err)
    }

    fun removePhoto(id: String) = viewModelScope.launch(Dispatchers.IO) {
        dao.photo(id)?.let { dao.deletePhoto(id); runCatching { File(it.filePath).delete() } }
    }

    fun recordsFor(scope: String): List<InspectionWithPhotos> {
        val a = all.value.orEmpty()
        val list = when (scope) {
            "filtered" -> filtered.value.orEmpty()
            "selected" -> a.filter { it.inspection.id in selection.value }
            else -> a
        }
        return list.sortedBy { it.inspection.inspectedAt }
    }

    fun export(scope: String, format: String, onResult: (ExportedFile?, String?) -> Unit) = viewModelScope.launch {
        val rows = recordsFor(scope)
        if (rows.isEmpty()) { onResult(null, "No records match the selected scope."); return@launch }
        val now = System.currentTimeMillis()
        val filterText = when (scope) { "filtered" -> filter.value.summary(); "selected" -> "Selected records (${rows.size})"; else -> "All records" }
        val meta = ReportMeta(prefs.reportTitle, prefs.officeName, now, filterText)
        val ext = if (format == "xlsx") "xlsx" else "pdf"
        val tag = if (format == "pdf_detail") "Detailed" else "Inspection"
        val file = File(app.filesDir, "reports/LESCO_${tag}_Report_${Fmt.stamp(now)}.$ext")
        val res = withContext(Dispatchers.IO) {
            try {
                when (format) {
                    "xlsx" -> { XlsxWriter.write(file, rows, meta); ExportedFile(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "${rows.size} records") }
                    "pdf_detail" -> { val r = PdfWriter(meta, rows).detailed(file)
                        ExportedFile(file, "application/pdf", "${r.pages} pages, ${r.photosEmbedded} photos embedded" + if (r.photosFailed > 0) ", ${r.photosFailed} photo file(s) missing" else "") }
                    else -> { val r = PdfWriter(meta, rows).compact(file); ExportedFile(file, "application/pdf", "${r.pages} pages") }
                } to null
            } catch (e: Throwable) { file.delete(); null to (e.message ?: "Export failed") }
        }
        onResult(res.first, res.second)
    }

    fun shareIntent(f: File, mime: String): Intent {
        val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = android.content.ClipData.newRawUri(f.name, uri)
        }
        return Intent.createChooser(send, "Share ${f.name}").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    fun openIntent(f: File, mime: String): Intent {
        val uri = FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", f)
        return Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, mime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) }
    }
}
