package com.lesco.fieldrecovery.util

import android.content.Context
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.*

object Money {
    /** Parses user input like "12,500" or "1250.50" into paisa. Returns null if malformed or negative. */
    fun parse(input: String): Long? {
        val s = input.trim().replace(",", "").replace(Regex("^(?i)rs\\.?\\s*"), "")
        if (s.isEmpty()) return 0L
        if (!Regex("^\\d{1,12}(\\.\\d{1,2})?$").matches(s)) return null
        return BigDecimal(s).movePointRight(2).setScale(0, RoundingMode.UNNECESSARY).toLong()
    }
    fun toDecimal(paisa: Long): BigDecimal = BigDecimal.valueOf(paisa, 2)
    fun format(paisa: Long): String {
        val d = toDecimal(paisa)
        val fmt = java.text.DecimalFormat(if (paisa % 100 == 0L) "#,##0" else "#,##0.00")
        return "Rs. " + fmt.format(d)
    }
    fun plain(paisa: Long): String = toDecimal(paisa).toPlainString()
}

object Fmt {
    fun dateTime(ms: Long): String = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.US).format(Date(ms))
    fun dateTimeSec(ms: Long): String = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US).format(Date(ms))
    fun stamp(ms: Long): String = SimpleDateFormat("yyyy-MM-dd_HHmmss", Locale.US).format(Date(ms))
    fun date(ms: Long): String = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(ms))
    fun gps(lat: Double?, lon: Double?, acc: Float?): String =
        if (lat == null || lon == null) "Not recorded"
        else String.format(Locale.US, "%.6f, %.6f", lat, lon) + (acc?.let { String.format(Locale.US, " (±%.0f m)", it) } ?: "")
    fun startOfDay(ms: Long): Long = Calendar.getInstance().apply { timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var officeName: String get() = sp.getString("office", "Revenue Office MughalPura, Lahore")!!; set(v) = sp.edit().putString("office", v).apply()
    var reportTitle: String get() = sp.getString("title", "LESCO Field Recovery & Inspection Report")!!; set(v) = sp.edit().putString("title", v).apply()
    var watermarkExtra: String get() = sp.getString("wm", "")!!; set(v) = sp.edit().putString("wm", v).apply()
    var jpegQuality: Int get() = sp.getInt("q", 85); set(v) = sp.edit().putInt("q", v.coerceIn(50, 100)).apply()
    /** 0 = system, 1 = light, 2 = dark */
    var theme: Int get() = sp.getInt("theme", 0); set(v) = sp.edit().putInt("theme", v).apply()
}

fun safeName(s: String): String = s.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifEmpty { "ref" }
