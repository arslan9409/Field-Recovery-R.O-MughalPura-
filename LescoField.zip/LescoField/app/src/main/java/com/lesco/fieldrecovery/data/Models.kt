package com.lesco.fieldrecovery.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

enum class DefaulterCategory(val label: String) {
    M1_2("1 to 2 Months Defaulter"), M3_PLUS("3 Months and Above Defaulter"),
    DEAD("Dead Defaulter"), RUNNING("0 Month Payment / Running")
}
enum class MeterStatus(val label: String) {
    RUNNING("Meter Running at Site"), REMOVED_SPOT("Meter Removed on Spot (Non-Payment)"),
    ALREADY_REMOVED("Meter Already Removed"), DIRECT_SUPPLY("Direct Supply / Electricity Theft Detected")
}
enum class LegalAction(val label: String) {
    PROMISED("Citizen Urged / Payment Promised"), INSTALLMENTS("Bill Paid in Installments (Remaining Balance)"),
    COURT("Court Case Pending"), REFUSING("Direct Supply / Refusing to Remove")
}

@Entity(tableName = "inspections", indices = [Index("referenceNumber"), Index("inspectedAt")])
data class Inspection(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val referenceNumber: String,
    val consumerInfo: String = "",
    val pendingPaisa: Long = 0,
    val category: DefaulterCategory,
    val meterStatus: MeterStatus,
    val legalAction: LegalAction,
    val remarks: String = "",
    val inspectedAt: Long,          // epoch millis (UTC); displayed in device local time
    val latitude: Double? = null,
    val longitude: Double? = null,
    val accuracyM: Float? = null,
    val locationAt: Long? = null,
    val updatedAt: Long
)

@Entity(
    tableName = "photos",
    foreignKeys = [ForeignKey(Inspection::class, ["id"], ["inspectionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("inspectionId")]
)
data class Photo(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val inspectionId: String,
    val filePath: String,
    val fileName: String,
    val referenceNumber: String,
    val capturedAt: Long,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val accuracyM: Float? = null
)

data class InspectionWithPhotos(
    @Embedded val inspection: Inspection,
    @Relation(parentColumn = "id", entityColumn = "inspectionId") val photos: List<Photo>
)

@Dao
interface AppDao {
    @Transaction @Query("SELECT * FROM inspections ORDER BY inspectedAt DESC")
    fun observeAll(): Flow<List<InspectionWithPhotos>>
    @Transaction @Query("SELECT * FROM inspections WHERE id = :id")
    fun observe(id: String): Flow<InspectionWithPhotos?>
    @Transaction @Query("SELECT * FROM inspections WHERE id = :id")
    suspend fun get(id: String): InspectionWithPhotos?
    @Query("SELECT * FROM inspections WHERE referenceNumber = :ref COLLATE NOCASE")
    suspend fun byReference(ref: String): List<Inspection>
    @Insert suspend fun insert(i: Inspection)
    @Update suspend fun update(i: Inspection)
    @Query("DELETE FROM inspections WHERE id = :id") suspend fun delete(id: String)
    @Insert suspend fun insertPhoto(p: Photo)
    @Query("SELECT * FROM photos WHERE id = :id") suspend fun photo(id: String): Photo?
    @Query("DELETE FROM photos WHERE id = :id") suspend fun deletePhoto(id: String)
    @Query("SELECT filePath FROM photos WHERE inspectionId = :id") suspend fun photoPaths(id: String): List<String>
}

@Database(entities = [Inspection::class, Photo::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: android.content.Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "lesco_field.db").build().also { inst = it }
        }
    }
}
