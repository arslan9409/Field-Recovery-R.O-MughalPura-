package com.lesco.fieldrecovery.export

import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.lesco.fieldrecovery.data.InspectionWithPhotos
import com.lesco.fieldrecovery.util.Fmt
import com.lesco.fieldrecovery.util.Money
import java.io.File
import java.io.FileOutputStream

data class PdfResult(val photosEmbedded: Int, val photosFailed: Int, val pages: Int)

/**
 * Landscape A4 (842x595 pt). Text is drawn with StaticLayout so Android's text engine does Urdu shaping/RTL;
 * actual glyph coverage depends on the fonts installed on the device.
 */
class PdfWriter(private val meta: ReportMeta, private val rows: List<InspectionWithPhotos>) {
    private val W = 842; private val H = 595; private val M = 30f
    private val blue = Color.rgb(11, 60, 140); private val green = Color.rgb(27, 138, 60)
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private lateinit var c: Canvas
    private var y = 0f; private var pageNo = 0
    private var embedded = 0; private var failed = 0

    private fun tp(size: Float, bold: Boolean = false, color: Int = Color.BLACK) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }
    private fun layout(t: String, p: TextPaint, w: Int) =
        StaticLayout.Builder.obtain(t, 0, t.length, p, w).setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(false).build()

    private fun newPage(withTitle: Boolean = false) {
        page?.let { footer(); doc.finishPage(it) }
        pageNo++
        page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        c = page!!.canvas
        c.drawRect(0f, 0f, W.toFloat(), 8f, Paint().apply { color = blue })
        c.drawRect(0f, 8f, W.toFloat(), 11f, Paint().apply { color = green })
        y = M
        if (withTitle) {
            c.drawText(meta.title, M, y + 16, tp(18f, true, blue)); y += 24
            c.drawText(meta.office, M, y + 10, tp(11f, false, green)); y += 16
            val total = rows.sumOf { it.inspection.pendingPaisa }
            c.drawText("Generated: ${Fmt.dateTimeSec(meta.generatedAt)}    Records: ${rows.size}    Total recorded pending: ${Money.format(total)}", M, y + 9, tp(9f)); y += 13
            val f = layout("Filters: ${meta.filterSummary}", tp(9f), (W - 2 * M).toInt()); c.save(); c.translate(M, y); f.draw(c); c.restore(); y += f.height + 8
        }
    }
    private fun footer() {
        val p = tp(8f, color = Color.GRAY)
        c.drawText("LESCO Field Recovery & Inspection  |  Made by Arslan Mughal", M, H - 14f, p)
        c.drawText("Page $pageNo", W - M - 40f, H - 14f, p)
    }
    private fun ensure(h: Float, redraw: (() -> Unit)? = null) { if (y + h > H - 30f) { newPage(); redraw?.invoke() } }

    private fun table(headers: List<String>, widths: List<Int>, data: List<List<String>>) {
        val hp = tp(8.5f, true, Color.WHITE); val bp = tp(8f)
        fun header() {
            var x = M
            c.drawRect(M, y, M + widths.sum(), y + 18f, Paint().apply { color = blue })
            headers.forEachIndexed { i, h -> c.drawText(h, x + 3, y + 12f, hp); x += widths[i] }
            y += 18f
        }
        header()
        data.forEachIndexed { r, row ->
            val ls = row.mapIndexed { i, t -> layout(t, bp, widths[i] - 6) }
            val h = (ls.maxOf { it.height } + 6f)
            ensure(h) { header() }
            if (r % 2 == 1) c.drawRect(M, y, M + widths.sum(), y + h, Paint().apply { color = Color.rgb(238, 243, 251) })
            var x = M
            ls.forEachIndexed { i, l -> c.save(); c.translate(x + 3, y + 3); l.draw(c); c.restore(); x += widths[i] }
            c.drawLine(M, y + h, M + widths.sum(), y + h, Paint().apply { color = Color.LTGRAY; strokeWidth = 0.5f })
            y += h
        }
    }

    fun compact(file: File): PdfResult {
        newPage(true)
        table(listOf("S.No", "Date & Time", "Reference", "Consumer Name/Address", "Pending (Rs.)", "Defaulter Category", "Meter Status", "Legal / Payment"),
            listOf(32, 78, 90, 150, 70, 110, 120, 102),
            rows.mapIndexed { i, r -> val x = r.inspection
                listOf("${i + 1}", Fmt.dateTime(x.inspectedAt), x.referenceNumber, x.consumerInfo.ifEmpty { "-" }, Money.format(x.pendingPaisa), x.category.label, x.meterStatus.label, x.legalAction.label) })
        y += 14
        ensure(40f)
        c.drawText("Remarks, GPS and photo files", M, y + 12, tp(12f, true, blue)); y += 20
        table(listOf("S.No", "Reference", "Field Remarks", "GPS Location", "Photo File Name"), listOf(32, 90, 320, 150, 160),
            rows.mapIndexed { i, r -> listOf("${i + 1}", r.inspection.referenceNumber, r.inspection.remarks.ifEmpty { "-" }, gpsText(r), photoNames(r)) })
        return finish(file)
    }

    fun detailed(file: File): PdfResult {
        newPage(true)
        val lp = tp(9f, true, blue); val vp = tp(9.5f)
        rows.forEachIndexed { idx, r ->
            val x = r.inspection
            ensure(120f)
            c.drawRect(M, y, W - M, y + 20f, Paint().apply { color = blue })
            c.drawText("#${idx + 1}   REF: ${x.referenceNumber}", M + 6, y + 14f, tp(11f, true, Color.WHITE))
            val amt = Money.format(x.pendingPaisa); val ap = tp(11f, true, Color.WHITE)
            c.drawText(amt, W - M - 6 - ap.measureText(amt), y + 14f, ap); y += 26f
            listOf("Date & Time" to Fmt.dateTime(x.inspectedAt), "Consumer" to x.consumerInfo.ifEmpty { "-" },
                "Category" to x.category.label, "Meter Status" to x.meterStatus.label, "Legal / Payment" to x.legalAction.label,
                "Remarks" to x.remarks.ifEmpty { "-" }, "GPS" to gpsText(r), "Photos" to photoNames(r)).forEach { (k, v) ->
                val l = layout(v, vp, (W - 2 * M - 110).toInt()); ensure(l.height + 4f)
                c.drawText(k, M + 4, y + 10f, lp); c.save(); c.translate(M + 110, y); l.draw(c); c.restore(); y += l.height + 4f
            }
            y += 4f
            if (r.photos.isEmpty()) { c.drawText("No photographs recorded for this inspection.", M + 4, y + 10f, tp(9f, color = Color.GRAY)); y += 18f }
            else r.photos.chunked(2).forEach { pair ->
                val boxW = (W - 2 * M - 10) / 2f; val boxH = 230f
                ensure(boxH + 16f)
                pair.forEachIndexed { k, ph ->
                    val left = M + k * (boxW + 10f)
                    val bmp = decode(ph.filePath, 900)
                    if (bmp == null) {
                        failed++
                        c.drawRect(left, y, left + boxW, y + 40f, Paint().apply { style = Paint.Style.STROKE; color = Color.RED })
                        c.drawText("Photo file missing: ${ph.fileName}", left + 6, y + 24f, tp(9f, color = Color.RED))
                    } else {
                        val s = minOf(boxW / bmp.width, boxH / bmp.height)   // aspect preserved
                        val dw = bmp.width * s; val dh = bmp.height * s
                        c.drawBitmap(bmp, null, RectF(left, y, left + dw, y + dh), Paint(Paint.FILTER_BITMAP_FLAG))
                        bmp.recycle(); embedded++
                    }
                }
                y += boxH + 8f
            }
            y += 10f
        }
        return finish(file)
    }

    private fun decode(path: String, maxSide: Int): Bitmap? {
        val f = File(path); if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o); if (o.outWidth <= 0) return null
        var s = 1; while (maxOf(o.outWidth, o.outHeight) / s > maxSide) s *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun finish(file: File): PdfResult {
        page?.let { footer(); doc.finishPage(it) }
        val pages = pageNo
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".part")
        try { FileOutputStream(tmp).use { doc.writeTo(it) } } finally { doc.close() }
        if (tmp.length() == 0L || !tmp.renameTo(file)) { tmp.delete(); error("Could not write PDF (storage may be full)") }
        return PdfResult(embedded, failed, pages)
    }
}
