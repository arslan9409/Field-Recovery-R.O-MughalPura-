package com.lesco.fieldrecovery

import com.lesco.fieldrecovery.data.*
import com.lesco.fieldrecovery.export.XlsxWriter
import com.lesco.fieldrecovery.util.*
import org.junit.Assert.*
import org.junit.Test

class CoreTests {
    private fun rec(ref: String, paisa: Long, cat: DefaulterCategory = DefaulterCategory.M1_2, photos: Int = 0, t: Long = 1000, remarks: String = "") =
        Inspection(referenceNumber = ref, pendingPaisa = paisa, category = cat, meterStatus = MeterStatus.RUNNING, legalAction = LegalAction.PROMISED,
            remarks = remarks, inspectedAt = t, updatedAt = t).let { i ->
            InspectionWithPhotos(i, (1..photos).map { Photo(inspectionId = i.id, filePath = "/x$it", fileName = "p$it.jpg", referenceNumber = ref, capturedAt = t) }) }

    @Test fun moneyParsing() {
        assertEquals(1250050L, Money.parse("12,500.50"))
        assertEquals(0L, Money.parse("  "))
        assertNull(Money.parse("-5")); assertNull(Money.parse("12.345")); assertNull(Money.parse("abc"))
        assertEquals("Rs. 12,500.50", Money.format(1250050)); assertEquals("Rs. 100", Money.format(10000))
    }
    @Test fun totalsIgnorePhotoCount() {
        val l = listOf(rec("A", 10000, photos = 3), rec("B", 5050, photos = 0))
        assertEquals(15050L, totalPaisa(l))
    }
    @Test fun filterAndSort() {
        val l = listOf(rec("A1", 100, DefaulterCategory.DEAD, 1, 1, "wrong tariff"), rec("B2", 900, DefaulterCategory.M1_2, 0, 2))
        assertEquals(1, applyFilter(l, HistoryFilter(category = DefaulterCategory.DEAD)).size)
        assertEquals(1, applyFilter(l, HistoryFilter(query = "TARIFF")).size)
        assertEquals(1, applyFilter(l, HistoryFilter(hasPhotos = false)).size)
        assertEquals("B2", applyFilter(l, HistoryFilter(sort = SortBy.AMOUNT)).first().inspection.referenceNumber)
        assertEquals(2, applyFilter(l, HistoryFilter()).size)
    }
    @Test fun watermarkLines() {
        val tagged = Watermark.lines(WatermarkInfo("R-77", 0L, 31.5, 74.3, 8f))
        assertTrue(tagged[0].contains("R-77")); assertTrue(tagged.any { it.startsWith("GPS: 31.500000, 74.300000") && it.contains("8 m") })
        val untagged = Watermark.lines(WatermarkInfo("R-77", 0L, null, null, null))
        assertTrue(untagged.any { it.contains("not available") })
    }
    @Test fun xmlEscapingStripsIllegalChars() {
        assertEquals("a&amp;b&lt;c", XlsxWriter.esc("a&b<c")); assertEquals("ab", XlsxWriter.esc("a\u0001b"))
        assertEquals("=SUM(A1)", XlsxWriter.esc("=SUM(A1)"))   // stays literal text: written as inlineStr, never as a formula
    }
}
