# LESCO Field Recovery & Inspection (Android, offline-first)
Revenue Office MughalPura, Lahore. Made by Arslan Mughal.

## Build
- Android Studio Koala (2024.1.1) or newer, JDK 17, Android SDK 34, Gradle 8.7 (AGP 8.5.2, Kotlin 2.0.20, KSP 2.0.20-1.0.25).
- Open this folder in Android Studio and let it sync (it generates the Gradle wrapper jar). Run on a device/emulator with API 26+.
- Unit tests: `./gradlew testDebugUnitTest`. Debug APK: `./gradlew assembleDebug`.

## Architecture
Compose + Material 3, single `AppViewModel`, Room (SQLite) with `inspections` and `photos` (cascade delete). Money is stored as integer paisa.
- `util/Watermark.kt` burns REF (bold), date/time, GPS + accuracy, app name into the JPEG pixels (EXIF rotation applied).
- `util/Location.kt` uses `LocationManager` only; never invents coordinates.
- `export/XlsxWriter.kt` writes a real .xlsx (no library); text is inline strings, so nothing is evaluated as a formula.
- `export/PdfWriter.kt` uses `PdfDocument` + `StaticLayout` (compact and detailed-with-photos layouts).
- Sharing via `FileProvider` + `Intent.createChooser` (WhatsApp appears if installed).
Permissions: CAMERA, ACCESS_FINE/COARSE_LOCATION. No INTERNET permission.

## Status (honest)
**Written, NOT yet compiled or run** (no Android SDK in the authoring environment): everything above. Expect to fix small compile errors on first sync.
**Not implemented yet:** backup/restore package, Urdu UI string translations (Urdu text entry and PDF text shaping rely on the device's fonts and are unverified), instrumented UI tests, keep-original-photo option, Room migrations (schema v1 only), release signing.
Watermarks are visual annotations, not tamper-proof proof.
